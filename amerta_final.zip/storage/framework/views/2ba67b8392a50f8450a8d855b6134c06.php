<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Atlet - Riwayat Latihan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-gray-50 font-sans antialiased">

    <!-- Navbar -->
    <nav class="bg-emerald-600 p-4 text-white shadow-lg">
        <div class="container mx-auto flex justify-between items-center">
            <h1 class="text-xl font-bold flex items-center gap-2">
                <i class="fas fa-running"></i> My Progress
            </h1>
            <div class="flex items-center gap-4">
                <span class="text-sm">Halo, <?php echo e(Auth::user()->name); ?></span>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="text-xs bg-emerald-700 hover:bg-emerald-800 px-3 py-1 rounded transition">Keluar</button>
                </form>
            </div>
        </div>
    </nav>

    <main class="container mx-auto p-4 md:p-8">
        <!-- Stats Card -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div class="bg-white p-6 rounded-xl shadow-sm border-l-4 border-emerald-500">
                <div class="text-sm text-gray-500 uppercase font-bold">Total Kehadiran</div>
                <div class="text-3xl font-black text-gray-800"><?php echo e($stats['total_hadir']); ?></div>
            </div>
            <div class="bg-white p-6 rounded-xl shadow-sm border-l-4 border-blue-500">
                <div class="text-sm text-gray-500 uppercase font-bold">Latihan Bulan Ini</div>
                <div class="text-3xl font-black text-gray-800"><?php echo e($stats['hadir_bulan_ini']); ?></div>
            </div>
        </div>

        <!-- Riwayat Table -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="p-6 border-b border-gray-200">
                <h2 class="text-lg font-semibold text-gray-700">Riwayat Latihan Anda</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-gray-50 text-gray-600 text-xs uppercase font-bold">
                        <tr>
                            <th class="px-6 py-4">Tanggal</th>
                            <th class="px-6 py-4">Pelatih</th>
                            <th class="px-6 py-4">Lokasi</th>
                            <th class="px-6 py-4">Materi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 font-medium"><?php echo e(\Carbon\Carbon::parse($row->tanggal)->format('d M Y')); ?></td>
                            <td class="px-6 py-4 text-gray-600"><?php echo e($row->coach->name ?? 'Coach'); ?></td>
                            <td class="px-6 py-4 text-gray-600"><?php echo e($row->tempat); ?></td>
                            <td class="px-6 py-4 text-sm text-gray-500 italic"><?php echo e($row->materi ?? '-'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="px-6 py-10 text-center text-gray-400">Belum ada data latihan.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html><?php /**PATH C:\laragon\www\amerta3\resources\views/atlet/dashboard.blade.php ENDPATH**/ ?>